KARMIC 场景工作流说明

来源：此前生成的 04_FLUX浅色桌面场景_VAE修复.json。
两个 UI JSON 可拖入 ComfyUI，分别使用浅色与深色背景提示词。LoadImage 选择随包的 karmic-input.png。
需要 FLUX schnell、双 CLIP、ae.safetensors 和 BiRefNet 自定义节点及模型。
此版本只生成背景并通过遮罩合成原产品，不自动生成接触阴影，需后期融合。
已检查节点引用与合成边界，未执行本地生成。网页上的三张图为 ImageGen 视觉预演，不是本 JSON 的测试结果。
固定种子 20261008，4 步，CFG 1，Euler / Simple。
